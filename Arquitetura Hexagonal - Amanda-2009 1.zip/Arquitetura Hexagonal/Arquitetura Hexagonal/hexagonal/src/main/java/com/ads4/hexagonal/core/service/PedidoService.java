package com.ads4.hexagonal.core.service;

import com.ads4.hexagonal.core.domain.Pedido;
import com.ads4.hexagonal.core.ports.PedidoServicePort;

public class PedidoService implements PedidoServicePort {

    @Override
    public Pedido createPedido(Pedido pedido) {
        return pedido;
    }

}
