package com.ads4.hexagonal.adapters.Converter;

import org.springframework.stereotype.Component;

import com.ads4.hexagonal.adapters.dto.UsuarioDto;
import com.ads4.hexagonal.adapters.entities.UsuarioEntity;
import com.ads4.hexagonal.core.domain.Usuario;

@Component
public class UsuarioConverter {

    public Usuario toDomain(UsuarioDto dto) {
        return new Usuario(dto.getId(), dto.getNome(), dto.getEmail(), dto.getDataNascimento(), dto.getCpf(),
                dto.getEndereco(), dto.getSenha(), dto.getStatus(), dto.getTipo());
    }

    public UsuarioDto toDto(Usuario dominio) {
        return new UsuarioDto(dominio.getId(), dominio.getNome(), dominio.getEmail(), dominio.getDataNascimento(),
                dominio.getCpf(), dominio.getEndereco(), dominio.getSenha(), dominio.getStatus(), dominio.getTipo());
    }

    public UsuarioEntity toEntity(Usuario usuario) {
        return new UsuarioEntity(usuario.getId(), usuario.getNome(), usuario.getEmail(), usuario.getDataNascimento(),
                usuario.getCpf(), usuario.getEndereco(), usuario.getSenha(), usuario.getStatus(), usuario.getTipo());
    }

    public Usuario toDomain(UsuarioEntity entity) {
        return new Usuario(entity.getId(), entity.getNome(), entity.getEmail(), entity.getDataNascimento(),
                entity.getCpf(), entity.getEndereco(), entity.getSenha(), entity.getStatus(), entity.getTipo());
    }

}
