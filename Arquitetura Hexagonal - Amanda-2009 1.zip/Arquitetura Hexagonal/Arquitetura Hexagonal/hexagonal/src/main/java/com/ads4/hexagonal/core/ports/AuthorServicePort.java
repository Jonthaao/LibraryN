package com.ads4.hexagonal.core.ports;

import com.ads4.hexagonal.core.domain.Author;

public interface AuthorServicePort {

    Author createAuthor(Author author);

}
