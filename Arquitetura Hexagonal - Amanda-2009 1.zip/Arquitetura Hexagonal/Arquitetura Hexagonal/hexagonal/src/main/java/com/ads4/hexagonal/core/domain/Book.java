package com.ads4.hexagonal.core.domain;

public class Book {

    private int id;
    private String tittle;
    private String synopsis;
    private boolean active;
    private String publishDate;
    private int quantitie;

    public Book(int id, String tittle, String synopsis, boolean active, String publishDate, int quantitie) {
        this.id = id;
        this.tittle = tittle;
        this.synopsis = synopsis;
        this.active = active;
        this.publishDate = publishDate;
        this.quantitie = quantitie;
    }

    public Book() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTittle() {
        return tittle;
    }

    public void setTittle(String tittle) {
        this.tittle = tittle;
    }

    public String getSynopsis() {
        return synopsis;
    }

    public void setSynopsis(String synopsis) {
        this.synopsis = synopsis;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public String getPublishDate() {
        return publishDate;
    }

    public void setPublishDate(String publishDate) {
        this.publishDate = publishDate;
    }

    public int getQuantitie() {
        return quantitie;
    }

    public void setQuantitie(int quantitie) {
        this.quantitie = quantitie;
    }

}
