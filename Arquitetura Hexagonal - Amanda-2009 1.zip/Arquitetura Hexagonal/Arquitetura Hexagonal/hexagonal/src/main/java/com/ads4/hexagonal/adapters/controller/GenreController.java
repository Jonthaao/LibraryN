package com.ads4.hexagonal.adapters.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.ads4.hexagonal.adapters.Converter.GenreConverter;
import com.ads4.hexagonal.adapters.dto.GenreDto;
import com.ads4.hexagonal.core.ports.GenreServicePort;

@RestController
@RequestMapping("/genre")
public class GenreController {

    @Autowired
    GenreServicePort genreServicePort;

    @Autowired
    GenreConverter genreConverter;

    @PostMapping("/salvar")
    @ResponseStatus(HttpStatus.CREATED)
    public GenreDto create(@RequestBody GenreDto genreDto) {
        return genreConverter.toDto(genreServicePort.createGenre(genreConverter.toDomain(genreDto)));
    }

}
