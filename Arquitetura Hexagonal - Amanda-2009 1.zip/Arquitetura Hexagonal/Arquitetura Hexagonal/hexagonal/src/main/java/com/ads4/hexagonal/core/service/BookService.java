package com.ads4.hexagonal.core.service;

import com.ads4.hexagonal.core.domain.Book;
import com.ads4.hexagonal.core.ports.BookServicePort;

public class BookService implements BookServicePort {

    @Override
    public Book createBook(Book book) {
        return book;
    }

}
