package com.ads4.hexagonal.adapters.Converter;

import org.springframework.stereotype.Component;

import com.ads4.hexagonal.adapters.dto.AuthorDto;
import com.ads4.hexagonal.core.domain.Author;

@Component
public class AuthorConverter {

    public Author toDomain(AuthorDto dto) {
        return new Author(dto.getId(), dto.getName(), dto.getAge(), dto.getDescription());
    }

    public AuthorDto toDto(Author dominio) {
        return new AuthorDto(dominio.getId(), dominio.getName(), dominio.getAge(), dominio.getDescription());
    }

}
