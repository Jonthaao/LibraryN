package com.ads4.hexagonal.core.service;

import com.ads4.hexagonal.core.domain.Author;
import com.ads4.hexagonal.core.ports.AuthorServicePort;

public class AuthorService implements AuthorServicePort {

    @Override
    public Author createAuthor(Author author) {
        return author;
    }

}
