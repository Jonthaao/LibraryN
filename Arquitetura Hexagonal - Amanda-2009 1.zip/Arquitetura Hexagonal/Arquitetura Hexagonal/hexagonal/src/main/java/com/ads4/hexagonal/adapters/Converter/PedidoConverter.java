package com.ads4.hexagonal.adapters.Converter;

import org.springframework.stereotype.Component;

import com.ads4.hexagonal.adapters.dto.PedidoDto;
import com.ads4.hexagonal.core.domain.Pedido;

@Component
public class PedidoConverter {

    public Pedido toDomain(PedidoDto dto) {
        return new Pedido(dto.getId(), dto.getDataReserva(), dto.getDataDevolucao(), dto.isStatusDevolucao(),
                dto.getMulta());
    }

    public PedidoDto toDto(Pedido dominio) {
        return new PedidoDto(dominio.getId(), dominio.getDataReserva(), dominio.getDataDevolucao(),
                dominio.isStatusDevolucao(), dominio.getMulta());
    }

}
