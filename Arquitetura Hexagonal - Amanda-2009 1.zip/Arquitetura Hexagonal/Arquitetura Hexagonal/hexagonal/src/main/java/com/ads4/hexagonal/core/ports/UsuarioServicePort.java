package com.ads4.hexagonal.core.ports;

import com.ads4.hexagonal.core.domain.Usuario;
import java.util.List;

public interface UsuarioServicePort {

    Usuario createUsuario(Usuario usuario);

    List<Usuario> listAllUsuarios();

}
