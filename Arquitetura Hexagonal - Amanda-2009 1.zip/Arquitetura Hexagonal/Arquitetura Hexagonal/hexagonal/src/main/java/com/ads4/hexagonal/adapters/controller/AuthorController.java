package com.ads4.hexagonal.adapters.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.ads4.hexagonal.adapters.Converter.AuthorConverter;
import com.ads4.hexagonal.adapters.dto.AuthorDto;
import com.ads4.hexagonal.core.ports.AuthorServicePort;

@RestController
@RequestMapping("/author")
public class AuthorController {

    @Autowired
    AuthorServicePort authorServicePort;

    @Autowired
    AuthorConverter authorConverter;

    @PostMapping("/salvar")
    @ResponseStatus(HttpStatus.CREATED)
    public AuthorDto create(@RequestBody AuthorDto authorDto) {
        return authorConverter.toDto(authorServicePort.createAuthor(authorConverter.toDomain(authorDto)));
    }

}
