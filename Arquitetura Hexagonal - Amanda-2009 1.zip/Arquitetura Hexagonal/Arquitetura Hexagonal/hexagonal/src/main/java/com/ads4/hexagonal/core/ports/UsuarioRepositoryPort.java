package com.ads4.hexagonal.core.ports;
//contrato

//não tem metodos, por isso utilizamos interface

import com.ads4.hexagonal.core.domain.Usuario;
import java.util.List;

public interface UsuarioRepositoryPort {

    Usuario create(Usuario usuario);

    List<Usuario> findAll();

}
