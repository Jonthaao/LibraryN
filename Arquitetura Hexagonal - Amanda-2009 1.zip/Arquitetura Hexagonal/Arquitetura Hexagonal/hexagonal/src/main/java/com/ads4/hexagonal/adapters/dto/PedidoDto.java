package com.ads4.hexagonal.adapters.dto;

public class PedidoDto {

    private int id;
    private String dataReserva;
    private String dataDevolucao;
    private boolean statusDevolucao;
    private double multa;

    public PedidoDto() {
    }

    public PedidoDto(int id, String dataReserva, String dataDevolucao, boolean statusDevolucao, double multa) {
        this.id = id;
        this.dataReserva = dataReserva;
        this.dataDevolucao = dataDevolucao;
        this.statusDevolucao = statusDevolucao;
        this.multa = multa;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDataReserva() {
        return dataReserva;
    }

    public void setDataReserva(String dataReserva) {
        this.dataReserva = dataReserva;
    }

    public String getDataDevolucao() {
        return dataDevolucao;
    }

    public void setDataDevolucao(String dataDevolucao) {
        this.dataDevolucao = dataDevolucao;
    }

    public boolean isStatusDevolucao() {
        return statusDevolucao;
    }

    public void setStatusDevolucao(boolean statusDevolucao) {
        this.statusDevolucao = statusDevolucao;
    }

    public double getMulta() {
        return multa;
    }

    public void setMulta(double multa) {
        this.multa = multa;
    }

}
