package com.ads4.hexagonal.infraestrutura;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.ads4.hexagonal.core.ports.AuthorServicePort;
import com.ads4.hexagonal.core.ports.BookServicePort;
import com.ads4.hexagonal.core.ports.GenreServicePort;
import com.ads4.hexagonal.core.ports.PedidoServicePort;
import com.ads4.hexagonal.core.ports.UsuarioServicePort;
import com.ads4.hexagonal.core.service.AuthorService;
import com.ads4.hexagonal.core.service.BookService;
import com.ads4.hexagonal.core.service.GenreService;
import com.ads4.hexagonal.core.service.PedidoService;
import com.ads4.hexagonal.core.service.UsuarioService;

@Configuration
public class BeansConfig {

    @Bean
    public UsuarioServicePort usuarioServicePortImpl() {
        return new UsuarioService();
    }

    @Bean
    public BookServicePort bookServicePortImpl() {
        return new BookService();
    }

    @Bean
    public AuthorServicePort authorServicePortImpl() {
        return new AuthorService();
    }

    @Bean
    public GenreServicePort genreServicePortImpl() {
        return new GenreService();
    }

    @Bean
    public PedidoServicePort pedidoServicePortImpl() {
        return new PedidoService();
    }

}
