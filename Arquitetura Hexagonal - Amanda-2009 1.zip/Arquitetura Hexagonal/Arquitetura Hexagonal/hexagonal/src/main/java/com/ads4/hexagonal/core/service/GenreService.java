package com.ads4.hexagonal.core.service;

import com.ads4.hexagonal.core.domain.Genre;
import com.ads4.hexagonal.core.ports.GenreServicePort;

public class GenreService implements GenreServicePort {

    @Override
    public Genre createGenre(Genre genre) {
        return genre;
    }

}
