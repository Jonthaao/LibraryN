package com.ads4.hexagonal.core.ports;

import com.ads4.hexagonal.core.domain.Book;

public interface BookServicePort {

    Book createBook(Book book);

}
