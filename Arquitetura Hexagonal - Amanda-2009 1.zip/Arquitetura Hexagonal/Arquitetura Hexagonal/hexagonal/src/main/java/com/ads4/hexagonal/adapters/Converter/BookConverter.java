package com.ads4.hexagonal.adapters.Converter;

import org.springframework.stereotype.Component;

import com.ads4.hexagonal.adapters.dto.BookDto;
import com.ads4.hexagonal.core.domain.Book;

@Component
public class BookConverter {

    public Book toDomain(BookDto dto) {
        return new Book(dto.getId(), dto.getTittle(), dto.getSynopsis(), dto.isActive(), dto.getPublishDate(),
                dto.getQuantitie());
    }

    public BookDto toDto(Book dominio) {
        return new BookDto(dominio.getId(), dominio.getTittle(), dominio.getSynopsis(), dominio.isActive(),
                dominio.getPublishDate(), dominio.getQuantitie());
    }

}
