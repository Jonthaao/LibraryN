package com.ads4.hexagonal.adapters.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ads4.hexagonal.adapters.Converter.UsuarioConverter;
import com.ads4.hexagonal.adapters.entities.UsuarioEntity;
import com.ads4.hexagonal.core.domain.Usuario;
import com.ads4.hexagonal.core.ports.UsuarioRepositoryPort;
import java.util.stream.Collectors;

@Component
public class UsuarioRepositoryAdapter implements UsuarioRepositoryPort {

    @Autowired
    UsuarioRepository repository;

    @Autowired
    UsuarioConverter converter;

    @Override
    public Usuario create(Usuario usuario) {
        UsuarioEntity entity = converter.toEntity(usuario);
        return converter.toDomain(repository.save(entity));
    }

    @Override
    public List<Usuario> findAll() {
        List<UsuarioEntity> entities = repository.findAll();
        return entities.stream()
                .map(converter::toDomain)
                .collect(Collectors.toList());
    }

}
