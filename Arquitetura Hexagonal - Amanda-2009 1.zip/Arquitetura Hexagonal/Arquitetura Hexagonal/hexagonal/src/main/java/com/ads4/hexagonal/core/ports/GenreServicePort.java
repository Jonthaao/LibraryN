package com.ads4.hexagonal.core.ports;

import com.ads4.hexagonal.core.domain.Genre;

public interface GenreServicePort {

    Genre createGenre(Genre genre);

}
