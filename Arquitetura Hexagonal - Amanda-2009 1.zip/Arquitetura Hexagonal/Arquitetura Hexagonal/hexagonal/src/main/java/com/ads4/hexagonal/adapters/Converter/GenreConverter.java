package com.ads4.hexagonal.adapters.Converter;

import org.springframework.stereotype.Component;

import com.ads4.hexagonal.adapters.dto.GenreDto;
import com.ads4.hexagonal.core.domain.Genre;

@Component
public class GenreConverter {

    public Genre toDomain(GenreDto dto) {
        return new Genre(dto.getId(), dto.getName(), dto.getDescription());
    }

    public GenreDto toDto(Genre dominio) {
        return new GenreDto(dominio.getId(), dominio.getName(), dominio.getDescription());
    }

}
