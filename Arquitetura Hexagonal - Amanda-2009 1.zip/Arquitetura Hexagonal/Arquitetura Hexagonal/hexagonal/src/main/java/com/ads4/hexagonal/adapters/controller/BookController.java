package com.ads4.hexagonal.adapters.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.ads4.hexagonal.adapters.Converter.BookConverter;
import com.ads4.hexagonal.adapters.dto.BookDto;
import com.ads4.hexagonal.core.ports.BookServicePort;

@RestController
@RequestMapping("/book")
public class BookController {

    @Autowired
    BookServicePort bookServicePort;

    @Autowired
    BookConverter bookConverter;

    @PostMapping("/salvar")
    @ResponseStatus(HttpStatus.CREATED)
    public BookDto create(@RequestBody BookDto bookDto) {
        return bookConverter.toDto(bookServicePort.createBook(bookConverter.toDomain(bookDto)));
    }

}
