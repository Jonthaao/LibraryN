package com.ads4.hexagonal.core.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.ads4.hexagonal.core.domain.Usuario;
import com.ads4.hexagonal.core.ports.UsuarioRepositoryPort;
import com.ads4.hexagonal.core.ports.UsuarioServicePort;
import java.util.List;

public class UsuarioService implements UsuarioServicePort {

    @Autowired
    UsuarioRepositoryPort repositoryPort;

    @Override
    public Usuario createUsuario(Usuario usuario) {
        return repositoryPort.create(usuario);
    }

    @Override
    public List<Usuario> listAllUsuarios() {
        return repositoryPort.findAll();
    }

}
